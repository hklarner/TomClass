import qm as m

classifiers=[
	'Development Status :: 4 - Beta',
	'Intended Audience :: Science/Research',
	'Intended Audience :: Developers',
	'Programming Language :: Python',
	'License :: OSI Approved :: Python Software Foundation License',
	'Operating System :: OS Independent',
	'Topic :: Software Development',
	'Topic :: Scientific/Engineering'
]

kwargs = dict(scripts=['bin/qm.py'])
